rootProject.name = "nex-emotes"
