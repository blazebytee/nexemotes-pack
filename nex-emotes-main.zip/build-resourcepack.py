#!/usr/bin/env python3
"""Zips ./resource-pack into NexEmotes-ResourcePack.zip (deterministic) and prints its SHA-1.

Paste the SHA-1 into config.yml (resource-pack.sha1) and upload the zip to a DIRECT
download link (a link that downloads the file itself, not a web page).
"""
import hashlib, os, sys, zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
PACK = os.path.join(ROOT, "resource-pack")
OUT = os.path.join(ROOT, "NexEmotes-ResourcePack.zip")

files = []
for base, _dirs, names in os.walk(PACK):
    for n in names:
        full = os.path.join(base, n)
        files.append((os.path.relpath(full, PACK).replace(os.sep, "/"), full))
files.sort()

with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for arc, full in files:
        info = zipfile.ZipInfo(arc, date_time=(2020, 1, 1, 0, 0, 0))  # fixed time -> same bytes every build
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        with open(full, "rb") as f:
            z.writestr(info, f.read())

sha1 = hashlib.sha1(open(OUT, "rb").read()).hexdigest()
print("wrote", OUT)
print("sha1 ", sha1)
