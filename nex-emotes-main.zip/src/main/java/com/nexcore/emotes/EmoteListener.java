package com.nexcore.emotes;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.block.Action;

/** Ends emotes whenever the player does something that must not be combined with one. */
public final class EmoteListener implements Listener {
    private final NexEmotesPlugin plugin;
    private final EmoteManager emotes;

    public EmoteListener(NexEmotesPlugin plugin, EmoteManager emotes) {
        this.plugin = plugin;
        this.emotes = emotes;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (emotes.isEmoting(e.getPlayer().getUniqueId()) && e.getTo() != null) {
            emotes.checkMove(e.getPlayer(), e.getTo());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        emotes.stop(e.getPlayer().getUniqueId(), "Emote stopped.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        emotes.forget(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        emotes.stop(e.getEntity().getUniqueId(), null);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            if (e instanceof EntityDamageByEntityEvent) {
                emotes.markCombat(p.getUniqueId());
            }
            emotes.stop(p.getUniqueId(), "Emote stopped.");
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDealDamage(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p) {
            emotes.markCombat(p.getUniqueId());
            emotes.stop(p.getUniqueId(), "Emote stopped.");
        }
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent e) {
        emotes.stop(e.getPlayer().getUniqueId(), "Emote stopped.");
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        emotes.stop(e.getPlayer().getUniqueId(), "Emote stopped.");
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        emotes.stop(e.getPlayer().getUniqueId(), "Emote stopped.");
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.PHYSICAL) {
            emotes.stop(e.getPlayer().getUniqueId(), "Emote stopped.");
        }
    }

    @EventHandler
    public void onInventoryOpen(InventoryOpenEvent e) {
        if (e.getPlayer() instanceof Player p) {
            emotes.stop(p.getUniqueId(), "Emote stopped.");
        }
    }

    @EventHandler
    public void onGameMode(PlayerGameModeChangeEvent e) {
        emotes.stop(e.getPlayer().getUniqueId(), null);
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        emotes.stop(e.getPlayer().getUniqueId(), "Emote stopped.");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (emotes.pluginSendsPack() && plugin.getConfig().getBoolean("resource-pack.send-on-join", true)) {
            Player p = e.getPlayer();
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline()) emotes.sendPack(p);
            }, 20L);
        }
    }

    @EventHandler
    public void onPackStatus(PlayerResourcePackStatusEvent e) {
        emotes.onPackStatus(e);
    }
}
