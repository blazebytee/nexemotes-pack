package com.nexcore.emotes;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/**
 * Runs emotes entirely on the server. Other players see them through vanilla features only:
 * arm swings, particles, sounds, and (for players who loaded our resource pack) a fake held
 * item sent with Player#sendEquipmentChange. Nothing here touches real inventories, movement
 * or stats, so emotes cannot give a gameplay advantage.
 */
public final class EmoteManager {
    /** Fixed id so a re-sent/updated pack replaces the old one instead of stacking. */
    private static final UUID PACK_ID =
            UUID.nameUUIDFromBytes("nexemotes-resource-pack".getBytes(StandardCharsets.UTF_8));
    private static final int TICK_PERIOD = 2;

    private final NexEmotesPlugin plugin;
    private final Map<UUID, EmoteSession> sessions = new HashMap<>();
    /** Players who report our pack as loaded; only they are sent fake held items. */
    private final Set<UUID> packLoaded = new HashSet<>();
    private final Map<UUID, Long> lastCombat = new HashMap<>();
    private final Map<UUID, Long> lastEnd = new HashMap<>();
    private final Map<Emote.Pose, ItemStack> fakeItems = new HashMap<>();
    private BukkitTask task;

    public EmoteManager(NexEmotesPlugin plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- lifecycle

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, TICK_PERIOD);
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            stop(id, null);
        }
    }

    // ---------------------------------------------------------------- queries

    public boolean isEmoting(UUID id) {
        return sessions.containsKey(id);
    }

    public int activeCount() {
        return sessions.size();
    }

    public int packLoadedCount() {
        return packLoaded.size();
    }

    // ---------------------------------------------------------------- starting / stopping

    /** Returns null on success, otherwise a message to show the player. */
    public String startEmote(Player p, Emote emote) {
        UUID id = p.getUniqueId();
        if (!p.hasPermission("nexemotes.use") || !p.hasPermission(emote.permission())) {
            return "You don't have permission to use that emote.";
        }
        boolean replacing = sessions.containsKey(id);
        long now = System.currentTimeMillis();

        if (!replacing) {
            long cooldownMs = (long) (plugin.getConfig().getDouble("emotes.cooldown-seconds", 3) * 1000);
            Long ended = lastEnd.get(id);
            if (ended != null && now - ended < cooldownMs) {
                return "Wait a moment before emoting again.";
            }
        }
        long combatMs = (long) (plugin.getConfig().getDouble("emotes.combat-lock-seconds", 5) * 1000);
        Long fought = lastCombat.get(id);
        if (fought != null && now - fought < combatMs) {
            return "You can't emote right after combat.";
        }

        String blocked = blockedReason(p);
        if (blocked != null) {
            return blocked;
        }

        if (replacing) {
            stop(id, null);
            lastEnd.remove(id); // switching emotes shouldn't trigger the cooldown
        }

        ItemStack fake = fakeItemFor(emote.pose());
        EmoteSession session = new EmoteSession(id, emote, p.getLocation().clone(), fake);
        sessions.put(id, session);

        if (emote.pose() == Emote.Pose.HANDS_UP) {
            // Held crossbow arms follow the head pitch, so look up once to raise the hands.
            p.setRotation(p.getLocation().getYaw(), -75f);
        }
        if (fake != null) {
            sendFake(p, session);
        }
        p.sendActionBar(Component.text(emote.display() + " - move or sneak to stop", NamedTextColor.AQUA));
        return null;
    }

    @SuppressWarnings("deprecation")
    private String blockedReason(Player p) {
        if (p.isDead() || p.getGameMode() == GameMode.SPECTATOR) return "You can't emote right now.";
        if (p.isSleeping() || p.isInsideVehicle()) return "You can't emote while sleeping or riding.";
        if (p.isGliding() || p.isSwimming() || p.isFlying() || p.isInWater()) {
            return "You can't emote while flying, gliding or swimming.";
        }
        if (p.isSneaking()) return "Stop sneaking to emote.";
        if (!p.isOnGround()) return "You need to be standing on the ground to emote.";
        return null;
    }

    /** Stops the emote if one is running. A non-null reason is shown to the player. */
    public boolean stop(UUID id, String reason) {
        EmoteSession s = sessions.remove(id);
        if (s == null) return false;
        lastEnd.put(id, System.currentTimeMillis());
        Player p = Bukkit.getPlayer(id);
        if (p != null && p.isOnline()) {
            if (s.fakeItem != null) restoreReal(p);
            if (reason != null) p.sendActionBar(Component.text(reason, NamedTextColor.GRAY));
        }
        return true;
    }

    /** Called from movement events with the position the player is about to be at. */
    public void checkMove(Player p, Location to) {
        EmoteSession s = sessions.get(p.getUniqueId());
        if (s != null && movedTooFar(s, to)) {
            stop(p.getUniqueId(), "Emote stopped.");
        }
    }

    public void markCombat(UUID id) {
        lastCombat.put(id, System.currentTimeMillis());
    }

    public void forget(UUID id) {
        stop(id, null);
        packLoaded.remove(id);
        lastCombat.remove(id);
        lastEnd.remove(id);
    }

    private boolean movedTooFar(EmoteSession s, Location to) {
        if (to.getWorld() == null || !to.getWorld().equals(s.start.getWorld())) return true;
        double tol = plugin.getConfig().getDouble("emotes.move-tolerance", 0.3);
        double dx = to.getX() - s.start.getX();
        double dz = to.getZ() - s.start.getZ();
        double dy = to.getY() - s.start.getY();
        return dx * dx + dz * dz > tol * tol || Math.abs(dy) > 0.25;
    }

    // ---------------------------------------------------------------- per-tick work

    private void tick() {
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            EmoteSession s = sessions.get(id);
            if (s == null) continue;
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline() || p.isDead()) {
                stop(id, null);
                continue;
            }
            if (p.isSneaking() || movedTooFar(s, p.getLocation())) {
                stop(id, "Emote stopped.");
                continue;
            }
            if (s.age >= s.emote.ticks()) {
                stop(id, null);
                continue;
            }
            effects(p, s);
            if (s.fakeItem != null && s.age % 20 == 0) {
                sendFake(p, s); // keep the pose alive if the server re-syncs real equipment
            }
            s.age += TICK_PERIOD;
        }
    }

    private void effects(Player p, EmoteSession s) {
        World w = p.getWorld();
        Location loc = p.getLocation();
        switch (s.emote) {
            case CLAP:
                if (s.age % 4 == 0) {
                    // A player can only animate one arm at a time, so swing the arms in turn.
                    boolean second = (s.age / 4) % 2 == 1;
                    if (second) {
                        p.swingOffHand();
                        // the clap lands when the second arm swings
                        w.playSound(loc, "block.note_block.snare", SoundCategory.PLAYERS, 0.6f, 2.0f);
                        w.spawnParticle(Particle.CLOUD, inFront(p, 1.1, 0.45), 2, 0.05, 0.05, 0.05, 0.01);
                    } else {
                        p.swingMainHand();
                    }
                }
                break;
            case CRY:
                tears(p, w);
                if (s.age % 40 == 0) {
                    w.playSound(loc, "entity.wolf.whine", SoundCategory.PLAYERS, 0.5f, 1.3f);
                }
                break;
            case NEX:
                if (s.age == 0) {
                    w.playSound(loc, "entity.player.levelup", SoundCategory.PLAYERS, 0.7f, 1.2f);
                }
                w.spawnParticle(Particle.END_ROD, inFront(p, 1.3, 0.5), 2, 0.25, 0.25, 0.25, 0.01);
                break;
            case HANDSUP:
                if (s.age == 0) {
                    w.playSound(loc, "entity.experience_orb.pickup", SoundCategory.PLAYERS, 0.6f, 1.0f);
                }
                if (s.age % 6 == 0) {
                    w.spawnParticle(Particle.HAPPY_VILLAGER, loc.clone().add(0, 2.2, 0), 3, 0.3, 0.2, 0.3, 0);
                }
                break;
            default:
                break;
        }
    }

    /** Unit vector the player faces, ignoring pitch. */
    private static Vector facing(Player p) {
        double yaw = Math.toRadians(p.getLocation().getYaw());
        return new Vector(-Math.sin(yaw), 0, Math.cos(yaw));
    }

    private static Location inFront(Player p, double height, double forward) {
        return p.getLocation().add(0, height, 0).add(facing(p).multiply(forward));
    }

    private static void tears(Player p, World w) {
        Vector d = facing(p);
        Vector right = new Vector(-d.getZ(), 0, d.getX());
        Location base = p.getEyeLocation().add(d.clone().multiply(0.25)).add(0, -0.1, 0);
        for (int sign = -1; sign <= 1; sign += 2) {
            Location cheek = base.clone().add(right.clone().multiply(0.15 * sign));
            w.spawnParticle(Particle.FALLING_WATER, cheek, 1, 0, 0, 0, 0);
        }
    }

    // ---------------------------------------------------------------- fake held item

    private ItemStack fakeItemFor(Emote.Pose pose) {
        if (pose == Emote.Pose.NONE) return null;
        return fakeItems.computeIfAbsent(pose, k -> {
            // A charged crossbow makes other clients draw the two-handed "holding up" arm pose.
            // The resource pack swaps its look for the NexCore logo or an invisible model.
            ItemStack stack = new ItemStack(Material.CROSSBOW);
            CrossbowMeta meta = (CrossbowMeta) stack.getItemMeta();
            meta.addChargedProjectile(new ItemStack(Material.ARROW));
            String model = (k == Emote.Pose.LOGO) ? "nexemotes:logo" : "nexemotes:hold";
            meta.setItemModel(NamespacedKey.fromString(model));
            stack.setItemMeta(meta);
            return stack;
        });
    }

    private void sendFake(Player p, EmoteSession s) {
        for (Player viewer : p.getTrackedBy()) {
            if (viewer != p && packLoaded.contains(viewer.getUniqueId())) {
                viewer.sendEquipmentChange(p, EquipmentSlot.HAND, s.fakeItem);
            }
        }
    }

    private void restoreReal(Player p) {
        ItemStack real = p.getInventory().getItemInMainHand();
        for (Player viewer : p.getTrackedBy()) {
            if (viewer != p && packLoaded.contains(viewer.getUniqueId())) {
                viewer.sendEquipmentChange(p, EquipmentSlot.HAND, real);
            }
        }
    }

    // ---------------------------------------------------------------- resource pack

    public boolean pluginSendsPack() {
        return !plugin.getConfig().getString("resource-pack.url", "").trim().isEmpty();
    }

    /** Sends the configured pack to the player. Returns false if no URL is configured. */
    public boolean sendPack(Player p) {
        String url = plugin.getConfig().getString("resource-pack.url", "").trim();
        if (url.isEmpty()) return false;
        byte[] hash = parseSha1(plugin.getConfig().getString("resource-pack.sha1", ""));
        String prompt = plugin.getConfig().getString("resource-pack.prompt", "");
        boolean force = plugin.getConfig().getBoolean("resource-pack.required", false);
        p.addResourcePack(PACK_ID, url, hash, prompt.isEmpty() ? null : prompt, force);
        return true;
    }

    public void onPackStatus(PlayerResourcePackStatusEvent e) {
        // If we send the pack ourselves, only react to our own pack's status.
        if (pluginSendsPack() && !PACK_ID.equals(e.getID())) return;
        UUID id = e.getPlayer().getUniqueId();
        switch (e.getStatus()) {
            case SUCCESSFULLY_LOADED:
                packLoaded.add(id);
                break;
            case DECLINED:
            case FAILED_DOWNLOAD:
            case FAILED_RELOAD:
            case INVALID_URL:
            case DISCARDED:
                packLoaded.remove(id);
                break;
            default:
                break;
        }
    }

    private byte[] parseSha1(String hex) {
        String h = hex == null ? "" : hex.trim().toLowerCase();
        if (h.length() != 40) {
            if (!h.isEmpty()) plugin.getLogger().warning("resource-pack.sha1 must be 40 hex characters; ignoring it.");
            return null;
        }
        byte[] out = new byte[20];
        for (int i = 0; i < 20; i++) {
            int hi = Character.digit(h.charAt(i * 2), 16);
            int lo = Character.digit(h.charAt(i * 2 + 1), 16);
            if (hi < 0 || lo < 0) {
                plugin.getLogger().warning("resource-pack.sha1 contains non-hex characters; ignoring it.");
                return null;
            }
            out[i] = (byte) ((hi << 4) | lo);
        }
        return out;
    }
}
