package com.nexcore.emotes;

import java.util.Locale;

/** The four NexCore emotes. Durations are in server ticks (20 ticks = 1 second). */
public enum Emote {
    CLAP("clap", "Clap", 60, Pose.NONE),
    NEX("nex", "Nex Special", 100, Pose.LOGO),
    CRY("cry", "Cry", 100, Pose.NONE),
    HANDSUP("handsup", "Hands Up", 80, Pose.HANDS_UP);

    /** Which fake held item (if any) viewers see during the emote. */
    public enum Pose { NONE, LOGO, HANDS_UP }

    private final String id;
    private final String display;
    private final int ticks;
    private final Pose pose;

    Emote(String id, String display, int ticks, Pose pose) {
        this.id = id;
        this.display = display;
        this.ticks = ticks;
        this.pose = pose;
    }

    public String id() { return id; }
    public String display() { return display; }
    public int ticks() { return ticks; }
    public Pose pose() { return pose; }
    public String permission() { return "nexemotes.emote." + id; }

    public static Emote byName(String raw) {
        if (raw == null) return null;
        String s = raw.toLowerCase(Locale.ROOT).replace("-", "").replace("_", "");
        switch (s) {
            case "clap": case "clapping": return CLAP;
            case "nex": case "nexspecial": case "special": return NEX;
            case "cry": case "crying": return CRY;
            case "handsup": case "hands": case "handup": return HANDSUP;
            default: return null;
        }
    }
}
