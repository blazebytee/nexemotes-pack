package com.nexcore.emotes;

import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

/** One player's running emote. Only touched from the main server thread. */
final class EmoteSession {
    final UUID playerId;
    final Emote emote;
    final Location start;
    /** Fake held item shown to viewers, or null when the emote has no pose item. */
    final ItemStack fakeItem;
    int age; // ticks since start

    EmoteSession(UUID playerId, Emote emote, Location start, ItemStack fakeItem) {
        this.playerId = playerId;
        this.emote = emote;
        this.start = start;
        this.fakeItem = fakeItem;
    }
}
