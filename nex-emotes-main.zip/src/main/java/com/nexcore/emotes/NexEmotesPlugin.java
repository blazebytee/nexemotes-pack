package com.nexcore.emotes;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** Nex Emotes - made by BlazeByte_. Plugin-only emotes for NexCoreMC. */
public final class NexEmotesPlugin extends JavaPlugin implements CommandExecutor, TabCompleter {
    private EmoteManager emotes;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        emotes = new EmoteManager(this);
        getServer().getPluginManager().registerEvents(new EmoteListener(this, emotes), this);
        for (String name : new String[] {"emote", "nexemotes"}) {
            if (getCommand(name) == null) {
                getLogger().severe("Command /" + name + " is missing from plugin.yml; disabling.");
                getServer().getPluginManager().disablePlugin(this);
                return;
            }
            getCommand(name).setExecutor(this);
            getCommand(name).setTabCompleter(this);
        }
        emotes.start();
        getLogger().info("Nex Emotes enabled. Players use /emote <clap|nex|cry|handsup>.");
        if (!emotes.pluginSendsPack()) {
            getLogger().warning("resource-pack.url is empty: the plugin will not send the resource pack. "
                    + "Load NexEmotes-ResourcePack.zip another way or set the url in config.yml.");
        }
    }

    @Override
    public void onDisable() {
        if (emotes != null) emotes.shutdown();
    }

    // ------------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("nexemotes")) {
            return adminCommand(sender, args);
        }
        return emoteCommand(sender, args);
    }

    private boolean emoteCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Run this in-game as a player.");
            return true;
        }
        if (args.length == 0) {
            say(player, "Usage: /emote <clap|nex|cry|handsup|stop>", NamedTextColor.YELLOW);
            return true;
        }
        if (args[0].equalsIgnoreCase("stop")) {
            if (!emotes.stop(player.getUniqueId(), "Emote stopped.")) {
                say(player, "You aren't emoting.", NamedTextColor.GRAY);
            }
            return true;
        }
        Emote emote = Emote.byName(args[0]);
        if (emote == null) {
            say(player, "Unknown emote. Use clap, nex, cry or handsup.", NamedTextColor.RED);
            return true;
        }
        String error = emotes.startEmote(player, emote);
        if (error != null) {
            say(player, error, NamedTextColor.RED);
        }
        return true;
    }

    private boolean adminCommand(CommandSender sender, String[] args) {
        String sub = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);
        // Keep the old test commands working: /nexemotes clap etc.
        Emote asEmote = Emote.byName(sub);
        if (asEmote != null) {
            return emoteCommand(sender, new String[] {sub});
        }
        switch (sub) {
            case "status":
                sender.sendMessage("Nex Emotes " + getPluginMeta().getVersion() + " (made by BlazeByte_)");
                sender.sendMessage("Active emotes: " + emotes.activeCount());
                sender.sendMessage("Players with the resource pack loaded: " + emotes.packLoadedCount());
                sender.sendMessage(emotes.pluginSendsPack()
                        ? "Resource pack: sent by this plugin on join."
                        : "Resource pack: not configured in config.yml (set resource-pack.url).");
                return true;
            case "reload":
                if (!sender.hasPermission("nexemotes.admin")) {
                    sender.sendMessage("You don't have permission.");
                    return true;
                }
                reloadConfig();
                sender.sendMessage("Nex Emotes config reloaded.");
                return true;
            case "pack":
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Run this in-game as a player.");
                    return true;
                }
                if (!emotes.sendPack(p)) {
                    sender.sendMessage("No resource-pack.url is set in config.yml.");
                } else {
                    sender.sendMessage("Resource pack sent.");
                }
                return true;
            default:
                sender.sendMessage("Usage: /nexemotes <status|reload|pack>");
                return true;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length != 1) return out;
        String prefix = args[0].toLowerCase(Locale.ROOT);
        if (command.getName().equalsIgnoreCase("nexemotes")) {
            for (String s : new String[] {"status", "reload", "pack"}) {
                if (s.startsWith(prefix)) out.add(s);
            }
            return out;
        }
        for (Emote e : Emote.values()) {
            if (e.id().startsWith(prefix) && sender.hasPermission(e.permission())) out.add(e.id());
        }
        if ("stop".startsWith(prefix)) out.add("stop");
        return out;
    }

    private static void say(Player p, String msg, NamedTextColor color) {
        p.sendMessage(Component.text(msg, color));
    }
}
