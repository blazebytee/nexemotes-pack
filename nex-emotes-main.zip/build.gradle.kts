plugins {
    java
}

group = "com.nexcore"
version = "2.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.release.set(21)
}

tasks.jar {
    archiveFileName.set("NexEmotes-Plugin.jar")
    // Reproducible output: same sources -> same bytes.
    isPreserveFileTimestamps = false
    isReproducibleFileOrder = true
}
