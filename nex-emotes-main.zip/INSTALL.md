# Nex Emotes 2.0 (plugin-only) - by BlazeByte_

Players need NO mod. Emotes are started with commands and everyone nearby sees them.

Emotes: /emote clap | nex | cry | handsup | stop     (aliases: /emotes, /nexemotes <emote>)

## 1. Build the plugin (needs JDK 21 + Gradle 8.x, internet for the Paper API)
    gradle wrapper            # once, if this folder has no gradlew yet (or copy gradlew/gradle/ from your old project)
    ./gradlew clean build --no-daemon      # Windows: gradlew.bat clean build --no-daemon
Output: build/libs/NexEmotes-Plugin.jar
If the compiler reports an unknown method/constant, send me the exact error text - this source
has not been compiled against the real Paper API yet.

## 2. Resource pack
NexEmotes-ResourcePack.zip is already built (python3 build-resourcepack.py rebuilds it and prints the SHA-1).
Upload it to a DIRECT download link, then in plugins/NexEmotes/config.yml set:
    resource-pack:
      url: "https://your-direct-link/NexEmotes-ResourcePack.zip"
      sha1: "<the 40-character SHA-1 for the exact zip you uploaded>"
Run /nexemotes reload, then rejoin (or /nexemotes pack).

## 3. Install on Minehut
Delete the OLD NexEmotes-Plugin.jar from the plugins folder, upload the new one, restart the server.
Console should print: "Nex Emotes enabled. Players use /emote ...".  Then try /nexemotes status.

## What players see
- clap:    arms swing in turn with a clap sound (vanilla, works without the pack)
- cry:     tears on both cheeks + whimper sound (works without the pack)
- nex:     two-handed pose holding the NexCore logo (needs the pack; others see particles/sound only)
- handsup: arms raised (needs the pack; you are tilted to look up once at the start)
An emote stops if the player moves, sneaks, takes/deals damage, clicks, changes hotbar slot,
opens an inventory, teleports, or after it finishes. It never changes inventory, movement or stats.

## Known limits
- The emoting player does not see their own pose in third person (clap/cry/particles they do see).
- Hand position of the logo may need tuning in assets/nexemotes/models/item/logo.json ("display").
